import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Navigation } from "@/components/navigation"
import Link from "next/link"

const projects = [
  {
    id: 1,
    title: "Modern Villa Tasarım ve İnşaatı",
    location: "İstanbul, Beşiktaş",
    image: "/modern-residential-exterior.png",
    description: "Çağdaş mimari anlayışla tasarlanan lüks villa projesi.",
  },
  {
    id: 2,
    title: "Ticari Kompleks Yenileme Projesi",
    location: "İstanbul, Maslak",
    image: "/commercial-office-building-modern.jpg",
    description: "Fonksiyonel ve estetik ofis binası tasarımı.",
  },
  {
    id: 3,
    title: "Eski Fabrika Binası Yeniden İnşaatı",
    location: "İstanbul, Tuzla",
    image: "/modern-industrial-building-exterior.jpg",
    description: "Endüstriyel yapının modern standartlara uygun yenilenmesi.",
  },
  {
    id: 4,
    title: "Tedarik Sistemi Kurulumu ve Oluşturulması",
    location: "Ankara, Çankaya",
    image: "/luxury-hotel-building-modern-architecture.jpg",
    description: "Kompleks tedarik sistemlerinin kurulumu ve optimizasyonu.",
  },
  {
    id: 5,
    title: "Jazzy Elite İnşaat Alışveriş Merkezi",
    location: "İstanbul, Kadıköy",
    image: "/shopping-mall.jpg",
    description: "Modern alışveriş merkezi tasarım ve inşaat projesi.",
  },
  {
    id: 6,
    title: "Fresh Concept İnşaat Yenileme",
    location: "Antalya, Kemer",
    image: "/luxury-apartment-building-contemporary.jpg",
    description: "Yenilikçi konsept ile yapı yenileme projesi.",
  },
]

export default function ProjectsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <section className="pt-24 pb-16 bg-slate-900 relative overflow-hidden">
        {/* Background pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0 bg-[url('/construction-blueprint-pattern.png')] bg-cover bg-center"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-white">
            {/* Breadcrumbs */}
            <div className="flex items-center text-sm text-white/70 mb-8">
              <Link href="/" className="hover:text-white transition-colors">
                Ana Sayfa
              </Link>
              <span className="mx-2">—</span>
              <span className="text-white">Projelerimiz</span>
            </div>

            <div className="mb-4 text-sm font-medium text-teal-400 tracking-wider uppercase">İNŞAAT FİRMALARI</div>
            <h1 className="text-4xl md:text-6xl font-bold text-balance mb-6">Projelerimiz</h1>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8">
            {projects.map((project) => (
              <Card
                key={project.id}
                className="group overflow-hidden bg-white shadow-lg hover:shadow-xl transition-all duration-300"
              >
                <div className="aspect-[4/3] overflow-hidden">
                  <img
                    src={project.image || "/placeholder.svg"}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold mb-4 text-slate-900">{project.title}</h3>

                  <div className="flex items-center text-sm text-teal-600 mb-4">
                    <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                      <path
                        fillRule="evenodd"
                        d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z"
                        clipRule="evenodd"
                      />
                    </svg>
                    {project.location}
                  </div>

                  <p className="text-gray-600 text-pretty mb-6 leading-relaxed">{project.description}</p>

                  <Button className="bg-yellow-500 hover:bg-yellow-600 text-slate-900 font-semibold px-6 py-2 rounded-none uppercase tracking-wide">
                    DETAYLAR
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <footer className="bg-slate-900 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <div className="w-6 h-6 bg-teal-500 rounded mr-2"></div>
                <span className="text-white font-bold">Karahisarlıoğlu</span>
                <span className="text-teal-400 font-bold ml-1">Yapı</span>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed">
                Ullamcorper velit sed ullamcorper morbi tincidunt. Molestie a iaculis at erat pellentesque adipiscing
                commodo elit at imperdiet.
              </p>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">İletişim</h4>
              <div className="space-y-2 text-sm text-gray-400">
                <p>📞 1 - 234 - 567 - 8910</p>
                <p>📧 info@karahisarliogluyapi.com.tr</p>
                <p>
                  📍 2947 Cyrils Viaduct
                  <br />
                  Fort Ritchiechester
                </p>
              </div>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Şirket</h4>
              <div className="space-y-2 text-sm">
                <Link href="/hakkimizda" className="text-gray-400 hover:text-white block transition-colors">
                  HAKKIMIZDA
                </Link>
                <Link href="/projeler" className="text-gray-400 hover:text-white block transition-colors">
                  HİZMETLER
                </Link>
                <Link href="/projeler" className="text-gray-400 hover:text-white block transition-colors">
                  PROJELER
                </Link>
                <Link href="#" className="text-gray-400 hover:text-white block transition-colors">
                  BLOG
                </Link>
              </div>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Haberlerimize Abone Olun</h4>
              <p className="text-gray-400 text-sm mb-4">
                Şirketimizin son günleri ve en son promosyonları hakkında bilgi edinin
              </p>
              <div className="flex">
                <input
                  type="email"
                  placeholder="E-posta adresiniz"
                  className="flex-1 px-3 py-2 bg-gray-800 text-white text-sm border border-gray-700 focus:outline-none focus:border-teal-500"
                />
                <Button className="bg-yellow-500 hover:bg-yellow-600 text-slate-900 px-4 py-2 rounded-none">→</Button>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              Medialove © Karahisarlıoğlu Yapı Template
              <br />
              Tüm hakları saklıdır Telif Hakkı 2025
            </p>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                <span className="text-slate-900 font-bold text-sm">f</span>
              </div>
              <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                <span className="text-slate-900 font-bold text-sm">t</span>
              </div>
              <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                <span className="text-slate-900 font-bold text-sm">in</span>
              </div>
              <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                <span className="text-slate-900 font-bold text-sm">@</span>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
