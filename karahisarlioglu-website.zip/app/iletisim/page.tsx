import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Navigation } from "@/components/navigation"
import { Phone, Mail, MapPin, Clock, Facebook, Instagram, Linkedin, Send } from "lucide-react"
import Link from "next/link"

const contactInfo = [
  {
    icon: Phone,
    title: "Telefon",
    details: ["+90 (212) 555 01 23", "+90 (532) 555 01 23"],
    description: "Pazartesi - Cuma: 08:00 - 18:00",
  },
  {
    icon: Mail,
    title: "E-posta",
    details: ["info@karahisarliogluyapi.com.tr", "proje@karahisarliogluyapi.com.tr"],
    description: "24 saat içinde yanıt garantisi",
  },
  {
    icon: MapPin,
    title: "Adres",
    details: ["Maslak Mahallesi, Büyükdere Caddesi", "No: 123, Sarıyer/İstanbul"],
    description: "Merkez ofisimiz",
  },
  {
    icon: Clock,
    title: "Çalışma Saatleri",
    details: ["Pazartesi - Cuma: 08:00 - 18:00", "Cumartesi: 09:00 - 15:00"],
    description: "Pazar günleri kapalı",
  },
]

const services = [
  "Konut İnşaatı",
  "Ticari Yapılar",
  "Endüstriyel Tesisler",
  "Mimari Tasarım",
  "Proje Danışmanlığı",
  "Yapı Denetimi",
  "Tadilat ve Renovasyon",
  "Peyzaj Düzenlemesi",
]

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <section className="pt-24 pb-16 bg-industrial-darker relative overflow-hidden">
        {/* Background pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0 bg-[url('/construction-blueprint-pattern.png')] bg-cover bg-center"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-white">
            {/* Breadcrumbs */}
            <div className="flex items-center text-sm text-white/70 mb-8">
              <Link href="/" className="hover:text-white transition-colors">
                Ana Sayfa
              </Link>
              <span className="mx-2">—</span>
              <span className="text-white">İletişim</span>
            </div>

            <div className="mb-4 text-sm font-medium text-accent tracking-wider uppercase">İLETİŞİM</div>
            <h1 className="text-4xl md:text-6xl font-bold text-balance mb-6">İletişim</h1>
            <p className="text-xl text-white/90 text-pretty max-w-3xl">
              Hayalinizdeki projeyi gerçeğe dönüştürmek için bizimle iletişime geçin.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            {contactInfo.map((info, index) => (
              <Card key={index} className="text-center hover:shadow-xl transition-all duration-300 border-border/50">
                <CardContent className="p-8">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-accent/10 rounded-full mb-6">
                    <info.icon className="h-8 w-8 text-accent" />
                  </div>
                  <h3 className="text-xl font-bold mb-4">{info.title}</h3>
                  <div className="space-y-1 mb-3">
                    {info.details.map((detail, idx) => (
                      <div key={idx} className="font-medium">
                        {detail}
                      </div>
                    ))}
                  </div>
                  <p className="text-sm text-muted-foreground">{info.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form & Map */}
      <section className="py-16 bg-secondary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16">
            {/* Contact Form */}
            <div>
              <div className="mb-4 text-sm font-medium text-muted-foreground tracking-wider uppercase">
                İLETİŞİM FORMU
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-balance mb-6">
                Projenizi <span className="text-accent">Konuşalım</span>
              </h2>
              <p className="text-muted-foreground text-pretty mb-8">
                Aşağıdaki formu doldurarak bize ulaşabilirsiniz. En kısa sürede size geri dönüş yapacağız.
              </p>

              <Card className="border-border/50">
                <CardContent className="p-8">
                  <form className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">Ad Soyad *</label>
                        <input
                          type="text"
                          required
                          className="w-full px-4 py-3 bg-input border border-border rounded-lg focus:ring-2 focus:ring-accent focus:border-transparent"
                          placeholder="Adınız ve soyadınız"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Telefon *</label>
                        <input
                          type="tel"
                          required
                          className="w-full px-4 py-3 bg-input border border-border rounded-lg focus:ring-2 focus:ring-accent focus:border-transparent"
                          placeholder="Telefon numaranız"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">E-posta *</label>
                      <input
                        type="email"
                        required
                        className="w-full px-4 py-3 bg-input border border-border rounded-lg focus:ring-2 focus:ring-accent focus:border-transparent"
                        placeholder="E-posta adresiniz"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Hizmet Türü</label>
                      <select className="w-full px-4 py-3 bg-input border border-border rounded-lg focus:ring-2 focus:ring-accent focus:border-transparent">
                        <option value="">Hizmet türü seçin</option>
                        {services.map((service, index) => (
                          <option key={index} value={service}>
                            {service}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Proje Detayları *</label>
                      <textarea
                        rows={5}
                        required
                        className="w-full px-4 py-3 bg-input border border-border rounded-lg focus:ring-2 focus:ring-accent focus:border-transparent resize-none"
                        placeholder="Projeniz hakkında detaylı bilgi verin..."
                      />
                    </div>

                    <div className="flex items-start space-x-3">
                      <input
                        type="checkbox"
                        id="privacy"
                        className="mt-1 h-4 w-4 text-accent border-border rounded focus:ring-accent"
                      />
                      <label htmlFor="privacy" className="text-sm text-muted-foreground">
                        Kişisel verilerimin işlenmesine ve{" "}
                        <Link href="#" className="text-accent hover:underline">
                          Gizlilik Politikası
                        </Link>
                        'nı kabul ediyorum.
                      </label>
                    </div>

                    <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground" size="lg">
                      <Send className="h-4 w-4 mr-2" />
                      MESAJ GÖNDER
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Map & Additional Info */}
            <div>
              <div className="mb-4 text-sm font-medium text-muted-foreground tracking-wider uppercase">KONUM</div>
              <h2 className="text-3xl md:text-4xl font-bold text-balance mb-6">
                Ofisimizi <span className="text-accent">Ziyaret Edin</span>
              </h2>

              {/* Map Placeholder */}
              <Card className="mb-8 border-border/50">
                <CardContent className="p-0">
                  <div className="aspect-[4/3] bg-muted rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <MapPin className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">Harita Yükleniyor...</p>
                      <p className="text-sm text-muted-foreground mt-2">
                        Maslak Mahallesi, Büyükdere Caddesi No: 123
                        <br />
                        Sarıyer/İstanbul
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Social Media */}
              <Card className="border-border/50">
                <CardContent className="p-8">
                  <h3 className="text-xl font-bold mb-6">Sosyal Medyada Takip Edin</h3>
                  <div className="flex space-x-4">
                    <Link
                      href="#"
                      className="inline-flex items-center justify-center w-12 h-12 bg-accent/10 hover:bg-accent/20 rounded-lg transition-colors"
                    >
                      <Facebook className="h-6 w-6 text-accent" />
                    </Link>
                    <Link
                      href="#"
                      className="inline-flex items-center justify-center w-12 h-12 bg-accent/10 hover:bg-accent/20 rounded-lg transition-colors"
                    >
                      <Instagram className="h-6 w-6 text-accent" />
                    </Link>
                    <Link
                      href="#"
                      className="inline-flex items-center justify-center w-12 h-12 bg-accent/10 hover:bg-accent/20 rounded-lg transition-colors"
                    >
                      <Linkedin className="h-6 w-6 text-accent" />
                    </Link>
                  </div>
                  <p className="text-muted-foreground text-sm mt-4">
                    Projelerimizi ve güncel haberlerimizi sosyal medya hesaplarımızdan takip edebilirsiniz.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-industrial-darker relative overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0 bg-[url('/construction-blueprint-pattern.png')] bg-cover bg-center"></div>
        </div>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-16">
            <div className="mb-4 text-sm font-medium text-accent tracking-wider uppercase">SIK SORULAN SORULAR</div>
            <h2 className="text-3xl md:text-4xl font-bold text-white text-balance mb-6">
              Merak <span className="text-accent">Edilenler</span>
            </h2>
          </div>

          <div className="space-y-6">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardContent className="p-6">
                <h3 className="font-bold mb-2 text-white">Proje süresi ne kadar?</h3>
                <p className="text-white/80">
                  Proje süresi, yapının büyüklüğü ve karmaşıklığına göre değişir. Ortalama bir konut projesi 6-12 ay,
                  ticari projeler ise 8-18 ay sürmektedir.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardContent className="p-6">
                <h3 className="font-bold mb-2 text-white">Ücretsiz keşif hizmeti veriyor musunuz?</h3>
                <p className="text-white/80">
                  Evet, tüm potansiyel müşterilerimize ücretsiz keşif ve ön değerlendirme hizmeti sunuyoruz.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardContent className="p-6">
                <h3 className="font-bold mb-2 text-white">Hangi bölgelerde hizmet veriyorsunuz?</h3>
                <p className="text-white/80">
                  Başta İstanbul olmak üzere, Türkiye'nin birçok ilinde projeler gerçekleştiriyoruz. Detaylı bilgi için
                  bizimle iletişime geçebilirsiniz.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <footer className="bg-industrial-darker py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <div className="w-6 h-6 bg-accent rounded mr-2"></div>
                <span className="text-white font-bold">Karahisarlıoğlu</span>
                <span className="text-accent font-bold ml-1">Yapı</span>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed">
                Hayalinizdeki projeyi gerçeğe dönüştürmek için bizimle iletişime geçin.
              </p>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">İletişim</h4>
              <div className="space-y-2 text-sm text-gray-400">
                <p>📞 +90 (212) 555 01 23</p>
                <p>📧 info@karahisarliogluyapi.com.tr</p>
                <p>📍 Maslak Mahallesi, Büyükdere Caddesi No: 123, Sarıyer/İstanbul</p>
              </div>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Şirket</h4>
              <div className="space-y-2 text-sm">
                <Link href="/hakkimizda" className="text-gray-400 hover:text-white block transition-colors">
                  HAKKIMIZDA
                </Link>
                <Link href="/projeler" className="text-gray-400 hover:text-white block transition-colors">
                  PROJELER
                </Link>
                <Link href="/ortaklar" className="text-gray-400 hover:text-white block transition-colors">
                  ORTAKLAR
                </Link>
                <Link href="/iletisim" className="text-gray-400 hover:text-white block transition-colors">
                  İLETİŞİM
                </Link>
              </div>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Haberlerimize Abone Olun</h4>
              <p className="text-gray-400 text-sm mb-4">
                Şirketimizin son gelişmeleri ve projeler hakkında bilgi edinin
              </p>
              <div className="flex">
                <input
                  type="email"
                  placeholder="E-posta adresiniz"
                  className="flex-1 px-3 py-2 bg-gray-800 text-white text-sm border border-gray-700 focus:outline-none focus:border-accent"
                />
                <Button className="bg-accent hover:bg-accent/90 text-accent-foreground px-4 py-2 rounded-none">
                  →
                </Button>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2025 Karahisarlıoğlu Yapı Tasarım Ltd.Şti.
              <br />
              Tüm hakları saklıdır.
            </p>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
                <span className="text-accent-foreground font-bold text-sm">f</span>
              </div>
              <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
                <span className="text-accent-foreground font-bold text-sm">t</span>
              </div>
              <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
                <span className="text-accent-foreground font-bold text-sm">in</span>
              </div>
              <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
                <span className="text-accent-foreground font-bold text-sm">@</span>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
