import { Button } from "@/components/ui/button"
import { Navigation } from "@/components/navigation"
import Link from "next/link"
import { CheckCircle } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <section className="pt-24 pb-16 bg-slate-900 relative overflow-hidden">
        {/* Background pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0 bg-[url('/construction-blueprint-pattern.png')] bg-cover bg-center"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-white">
            {/* Breadcrumbs */}
            <div className="flex items-center text-sm text-white/70 mb-8">
              <Link href="/" className="hover:text-white transition-colors">
                Ana Sayfa
              </Link>
              <span className="mx-2">—</span>
              <span className="text-white">Hakkımızda</span>
            </div>

            <div className="mb-4 text-sm font-medium text-teal-400 tracking-wider uppercase">İNŞAAT FİRMALARI</div>
            <h1 className="text-4xl md:text-6xl font-bold text-balance mb-6">Hakkımızda</h1>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <div className="mb-4 text-sm font-medium text-slate-600 tracking-wider uppercase">KİMİZ</div>
              <h2 className="text-3xl md:text-4xl font-bold text-balance mb-6">
                Fikirlerinizi ve Yeniliklerinizi <span className="text-teal-600">Hayata Geçiriyoruz</span>
              </h2>
              <p className="text-gray-600 text-pretty leading-relaxed mb-8">
                İnşaat ve yapısal ekibimiz, topluluklarımız için sürdürülebilir, yaratıcı ve verimli mühendislik
                çözümleri sağlamaya kararlıdır.
              </p>

              <div className="space-y-4 mb-8">
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-teal-600 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Yaşamı daha kolay hale getirme</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-teal-600 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Her çözümü burada doğru şekilde alın</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-teal-600 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Yenilik ve yaratıcılık</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-teal-600 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Bizimle mühendislik sadece bulma</span>
                </div>
              </div>

              <Button className="bg-yellow-500 hover:bg-yellow-600 text-slate-900 font-semibold px-8 py-3 rounded-none uppercase tracking-wide">
                ŞİMDİ DANIŞIN
              </Button>
            </div>

            <div className="relative">
              <img
                src="/construction-workers-planning.jpg"
                alt="İnşaat Ekibi"
                className="rounded-lg shadow-2xl w-full"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-slate-900 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0 bg-[url('/construction-blueprint-pattern.png')] bg-cover bg-center"></div>
        </div>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative text-center">
          <div className="mb-4 text-sm font-medium text-teal-400 tracking-wider uppercase">KİMİZ</div>
          <blockquote className="text-2xl md:text-3xl font-bold text-white leading-relaxed mb-8">
            "35 yıllık deneyimimizle müşterilerimize güven veren, sözünde duran bir firma olarak hizmet veriyoruz. Her
            projede en yüksek kalite standartlarını uygulayarak, uzun ömürlü ve dayanıklı yapılar inşa ediyoruz."
          </blockquote>
          <cite className="text-yellow-500 font-semibold tracking-wider uppercase">ALİ KARAHISARLIOĞLU</cite>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="mb-4 text-sm font-medium text-slate-600 tracking-wider uppercase">GELECEĞI HİSSET</div>
            <h2 className="text-3xl md:text-4xl font-bold text-balance mb-6">
              Öne Çıkan <span className="text-teal-600">Hizmetler</span>
            </h2>
          </div>

          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <img src="/construction-process-image.jpg" alt="İnşaat Süreci" className="rounded-lg shadow-2xl w-full" />
            </div>

            <div>
              <h3 className="text-2xl font-bold mb-6">Süreç Mühendisliği</h3>
              <p className="text-gray-600 text-pretty leading-relaxed mb-8">
                Vitae ultricies leo integer malesuada nunc vel. Molestie ac feugiat sed lectus vestibulum mattis
                ullamcorper velit. Viverra aliquet eget sit amet tellus cras adipiscing
              </p>

              <div className="space-y-4 mb-8">
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-teal-600 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Yaşamı daha kolay hale getirme</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-teal-600 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Her çözümü burada doğru şekilde alın</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-teal-600 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Yenilik ve yaratıcılık</span>
                </div>
              </div>

              <Button className="bg-yellow-500 hover:bg-yellow-600 text-slate-900 font-semibold px-6 py-2 rounded-none uppercase tracking-wide">
                DAHA FAZLA OKU
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-0">
            <div className="aspect-square overflow-hidden">
              <img
                src="/modern-residential-exterior.png"
                alt="Modern Konut"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
            <div className="aspect-square overflow-hidden">
              <img
                src="/commercial-office-building-modern.jpg"
                alt="Ticari Bina"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
            <div className="aspect-square overflow-hidden">
              <img
                src="/luxury-apartment-building-contemporary.jpg"
                alt="Lüks Apartman"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-balance mb-6">Neden Bizi Seçmelisiniz</h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            <div className="text-center">
              <div className="text-4xl font-bold text-teal-600 mb-2">500+</div>
              <p className="text-gray-600">Her Yıl Tamamlanan Projeler</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-teal-600 mb-2">35</div>
              <p className="text-gray-600">2020'de Milyon Euro Ciro</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-teal-600 mb-2">98%</div>
              <p className="text-gray-600">Yapı Kontrol Onay Oranı</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-teal-600 mb-2">150+</div>
              <p className="text-gray-600">Mühendislikte Aktif Projeler</p>
            </div>
          </div>

          <p className="text-center text-gray-600 text-pretty max-w-3xl mx-auto mb-12">
            Elementum sagittis vitae et leo duis ut diam. In nibh mauris cursus mattis molestie a iaculis at
          </p>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center text-slate-900 font-bold text-xl mx-auto mb-4">
                01
              </div>
              <h3 className="text-xl font-bold mb-4">Benzersiz Projeler</h3>
              <p className="text-gray-600 text-pretty">
                Senectus et netus et malesuada. Nunc pulvinar sapien et ligula ullamcorper malesuada proin
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center text-slate-900 font-bold text-xl mx-auto mb-4">
                02
              </div>
              <h3 className="text-xl font-bold mb-4">Değer Kolaylığı</h3>
              <p className="text-gray-600 text-pretty">Ullamcorper dignissim cras lobortis feugiat vivamus risus</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center text-slate-900 font-bold text-xl mx-auto mb-4">
                03
              </div>
              <h3 className="text-xl font-bold mb-4">Yeni Fikirler Uygulayın</h3>
              <p className="text-gray-600 text-pretty">
                Porttitor rhoncus dolor purus non enim praesent elementum facilisis. Nisi scelerisque eu ultrices vitae
                auctor eu augue ut lectus
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer matching projects page */}
      <footer className="bg-slate-900 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <div className="w-6 h-6 bg-teal-500 rounded mr-2"></div>
                <span className="text-white font-bold">Karahisarlıoğlu</span>
                <span className="text-teal-400 font-bold ml-1">Yapı</span>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed">
                Ullamcorper velit sed ullamcorper morbi tincidunt. Molestie a iaculis at erat pellentesque adipiscing
                commodo elit at imperdiet.
              </p>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">İletişim</h4>
              <div className="space-y-2 text-sm text-gray-400">
                <p>📞 1 - 234 - 567 - 8910</p>
                <p>📧 info@karahisarliogluyapi.com.tr</p>
                <p>
                  📍 2947 Cyrils Viaduct
                  <br />
                  Fort Ritchiechester
                </p>
              </div>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Şirket</h4>
              <div className="space-y-2 text-sm">
                <Link href="/hakkimizda" className="text-gray-400 hover:text-white block transition-colors">
                  HAKKIMIZDA
                </Link>
                <Link href="/projeler" className="text-gray-400 hover:text-white block transition-colors">
                  HİZMETLER
                </Link>
                <Link href="/projeler" className="text-gray-400 hover:text-white block transition-colors">
                  PROJELER
                </Link>
                <Link href="#" className="text-gray-400 hover:text-white block transition-colors">
                  BLOG
                </Link>
              </div>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Haberlerimize Abone Olun</h4>
              <p className="text-gray-400 text-sm mb-4">
                Şirketimizin son günleri ve en son promosyonları hakkında bilgi edinin
              </p>
              <div className="flex">
                <input
                  type="email"
                  placeholder="E-posta adresiniz"
                  className="flex-1 px-3 py-2 bg-gray-800 text-white text-sm border border-gray-700 focus:outline-none focus:border-teal-500"
                />
                <Button className="bg-yellow-500 hover:bg-yellow-600 text-slate-900 px-4 py-2 rounded-none">→</Button>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              Medialove © Karahisarlıoğlu Yapı Template
              <br />
              Tüm hakları saklıdır Telif Hakkı 2025
            </p>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                <span className="text-slate-900 font-bold text-sm">f</span>
              </div>
              <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                <span className="text-slate-900 font-bold text-sm">t</span>
              </div>
              <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                <span className="text-slate-900 font-bold text-sm">in</span>
              </div>
              <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                <span className="text-slate-900 font-bold text-sm">@</span>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
