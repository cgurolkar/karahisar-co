import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Navigation } from "@/components/navigation"
import { Users, Award, Handshake, Star, Globe, CheckCircle } from "lucide-react"
import Link from "next/link"

const partners = [
  {
    id: 1,
    name: "Yapı Kredi Bankası",
    category: "Finansal Partner",
    logo: "/placeholder.svg?height=80&width=200&text=Yapı+Kredi",
    description: "İnşaat projelerimizde finansal destek sağlayan güvenilir bankacılık ortağımız.",
    partnership: "2020'den beri",
  },
  {
    id: 2,
    name: "Akçansa Çimento",
    category: "Malzeme Tedarikçisi",
    logo: "/placeholder.svg?height=80&width=200&text=Akçansa",
    description: "Yüksek kaliteli çimento ve yapı malzemeleri tedarikçimiz.",
    partnership: "2018'den beri",
  },
  {
    id: 3,
    name: "Bosch Termoteknik",
    category: "Teknoloji Ortağı",
    logo: "/placeholder.svg?height=80&width=200&text=Bosch",
    description: "Akıllı ev sistemleri ve ısıtma çözümleri ortağımız.",
    partnership: "2019'dan beri",
  },
  {
    id: 4,
    name: "Kale Seramik",
    category: "Malzeme Tedarikçisi",
    logo: "/placeholder.svg?height=80&width=200&text=Kale+Seramik",
    description: "Premium seramik ve banyo ürünleri tedarikçimiz.",
    partnership: "2017'den beri",
  },
  {
    id: 5,
    name: "Schneider Electric",
    category: "Teknoloji Ortağı",
    logo: "/placeholder.svg?height=80&width=200&text=Schneider",
    description: "Elektrik sistemleri ve otomasyon çözümleri ortağımız.",
    partnership: "2021'den beri",
  },
  {
    id: 6,
    name: "İstanbul Büyükşehir Belediyesi",
    category: "Kamu Ortağı",
    logo: "/placeholder.svg?height=80&width=200&text=İBB",
    description: "Kamu projelerinde işbirliği yaptığımız belediye ortağımız.",
    partnership: "2016'dan beri",
  },
]

const clients = [
  {
    name: "Ahmet Yılmaz",
    project: "Modern Villa",
    testimonial: "Karahisarlıoğlu Yapı ile çalışmak harika bir deneyimdi. Profesyonel ekip ve kaliteli işçilik.",
    rating: 5,
    location: "İstanbul",
  },
  {
    name: "Mehmet Demir",
    project: "Ticari Bina",
    testimonial: "Zamanında teslim, bütçeye uygun ve mükemmel kalite. Kesinlikle tavsiye ederim.",
    rating: 5,
    location: "Ankara",
  },
  {
    name: "Fatma Kaya",
    project: "Apartman Yenileme",
    testimonial: "Detaylara gösterdikleri özen ve müşteri memnuniyeti odaklı yaklaşımları çok etkileyici.",
    rating: 5,
    location: "İzmir",
  },
]

const stats = [
  { number: "50+", label: "Güvenilir Partner", icon: Handshake },
  { number: "1000+", label: "Mutlu Müşteri", icon: Users },
  { number: "15+", label: "Yıllık Deneyim", icon: Award },
  { number: "25+", label: "Şehir", icon: Globe },
]

export default function PartnersPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <section className="pt-24 pb-16 bg-industrial-darker relative overflow-hidden">
        {/* Background pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0 bg-[url('/construction-blueprint-pattern.png')] bg-cover bg-center"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-white">
            {/* Breadcrumbs */}
            <div className="flex items-center text-sm text-white/70 mb-8">
              <Link href="/" className="hover:text-white transition-colors">
                Ana Sayfa
              </Link>
              <span className="mx-2">—</span>
              <span className="text-white">Ortaklar</span>
            </div>

            <div className="mb-4 text-sm font-medium text-accent tracking-wider uppercase">İŞ ORTAKLARI</div>
            <h1 className="text-4xl md:text-6xl font-bold text-balance mb-6">Ortaklarımız</h1>
            <p className="text-xl text-white/90 text-pretty max-w-3xl">
              Güçlü ortaklıklar ve memnun müşterilerle birlikte büyüyen bir aile.
            </p>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-accent/10 rounded-full mb-4">
                  <stat.icon className="h-8 w-8 text-accent" />
                </div>
                <div className="text-3xl font-bold text-foreground mb-2">{stat.number}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Partners Section */}
      <section className="py-16 bg-secondary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="mb-4 text-sm font-medium text-muted-foreground tracking-wider uppercase">
              İŞ ORTAKLARIMIZ
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-balance mb-6">
              Güvenilir <span className="text-accent">Ortaklarımız</span>
            </h2>
            <p className="text-lg text-muted-foreground text-pretty max-w-3xl mx-auto">
              Sektörün önde gelen firmaları ile kurduğumuz güçlü ortaklıklar sayesinde projelerimizde en yüksek kaliteyi
              garanti ediyoruz.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {partners.map((partner) => (
              <Card key={partner.id} className="group hover:shadow-xl transition-all duration-300 border-border/50">
                <CardContent className="p-8 text-center">
                  <div className="mb-6">
                    <img
                      src={partner.logo || "/placeholder.svg"}
                      alt={partner.name}
                      className="h-16 mx-auto object-contain"
                    />
                  </div>

                  <Badge variant="outline" className="mb-4 border-accent/30 text-accent">
                    {partner.category}
                  </Badge>

                  <h3 className="text-xl font-bold mb-3">{partner.name}</h3>

                  <p className="text-muted-foreground text-pretty mb-4">{partner.description}</p>

                  <div className="text-sm font-medium text-accent">{partner.partnership}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Client Testimonials */}
      <section className="py-16 bg-industrial-darker relative overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0 bg-[url('/construction-blueprint-pattern.png')] bg-cover bg-center"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-16">
            <div className="mb-4 text-sm font-medium text-accent tracking-wider uppercase">MÜŞTERİ YORUMLARI</div>
            <h2 className="text-3xl md:text-4xl font-bold text-white text-balance mb-6">
              Müşterilerimiz <span className="text-accent">Ne Diyor?</span>
            </h2>
            <p className="text-lg text-white/80 text-pretty max-w-3xl mx-auto">
              Projelerimizi tamamladığımız müşterilerimizin deneyimlerini dinleyin.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {clients.map((client, index) => (
              <Card
                key={index}
                className="group hover:shadow-xl transition-all duration-300 bg-white/10 backdrop-blur-sm border-white/20"
              >
                <CardContent className="p-8">
                  <div className="flex items-center mb-4">
                    {[...Array(client.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-accent fill-current" />
                    ))}
                  </div>

                  <blockquote className="text-white/90 text-pretty mb-6 italic">"{client.testimonial}"</blockquote>

                  <div className="border-t border-white/20 pt-4">
                    <div className="font-semibold text-white">{client.name}</div>
                    <div className="text-sm text-white/70">{client.project}</div>
                    <div className="text-sm text-accent">{client.location}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Partnership CTA */}
      <section className="py-24 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="mb-4 text-sm font-medium text-muted-foreground tracking-wider uppercase">ORTAKLIK</div>
          <h2 className="text-3xl md:text-4xl font-bold text-balance mb-6">
            Bizimle <span className="text-accent">Ortaklık Kurun</span>
          </h2>
          <p className="text-lg text-muted-foreground text-pretty mb-8">
            Sektörde güçlü bir yer edinmek ve kaliteli projeler üretmek için bizimle ortaklık kurmak istiyorsanız, size
            özel çözümler sunabiliriz.
          </p>

          <div className="space-y-6 mb-8">
            <div className="flex items-center justify-center space-x-4">
              <CheckCircle className="h-6 w-6 text-accent flex-shrink-0" />
              <div className="text-left">
                <h4 className="font-semibold">Güçlü İş Birliği</h4>
                <p className="text-muted-foreground text-sm">Uzun vadeli ve karşılıklı kazançlı ortaklıklar</p>
              </div>
            </div>

            <div className="flex items-center justify-center space-x-4">
              <CheckCircle className="h-6 w-6 text-accent flex-shrink-0" />
              <div className="text-left">
                <h4 className="font-semibold">Kaliteli Projeler</h4>
                <p className="text-muted-foreground text-sm">Yüksek standartlarda proje geliştirme</p>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="px-8 py-6 bg-accent hover:bg-accent/90 text-accent-foreground">
              ORTAKLIK BAŞVURUSU
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="px-8 py-6 border-accent text-accent hover:bg-accent hover:text-accent-foreground bg-transparent"
            >
              DAHA FAZLA BİLGİ
            </Button>
          </div>
        </div>
      </section>

      <footer className="bg-industrial-darker py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <div className="w-6 h-6 bg-accent rounded mr-2"></div>
                <span className="text-white font-bold">Karahisarlıoğlu</span>
                <span className="text-accent font-bold ml-1">Yapı</span>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed">
                Güçlü ortaklıklar ve memnun müşterilerle birlikte büyüyen, güvenilir inşaat firması.
              </p>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">İletişim</h4>
              <div className="space-y-2 text-sm text-gray-400">
                <p>📞 1 - 234 - 567 - 8910</p>
                <p>📧 info@karahisarliogluyapi.com.tr</p>
                <p>📍 İstanbul, Türkiye</p>
              </div>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Şirket</h4>
              <div className="space-y-2 text-sm">
                <Link href="/hakkimizda" className="text-gray-400 hover:text-white block transition-colors">
                  HAKKIMIZDA
                </Link>
                <Link href="/projeler" className="text-gray-400 hover:text-white block transition-colors">
                  PROJELER
                </Link>
                <Link href="/ortaklar" className="text-gray-400 hover:text-white block transition-colors">
                  ORTAKLAR
                </Link>
                <Link href="/iletisim" className="text-gray-400 hover:text-white block transition-colors">
                  İLETİŞİM
                </Link>
              </div>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Haberlerimize Abone Olun</h4>
              <p className="text-gray-400 text-sm mb-4">
                Şirketimizin son gelişmeleri ve projeler hakkında bilgi edinin
              </p>
              <div className="flex">
                <input
                  type="email"
                  placeholder="E-posta adresiniz"
                  className="flex-1 px-3 py-2 bg-gray-800 text-white text-sm border border-gray-700 focus:outline-none focus:border-accent"
                />
                <Button className="bg-accent hover:bg-accent/90 text-accent-foreground px-4 py-2 rounded-none">
                  →
                </Button>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2025 Karahisarlıoğlu Yapı Tasarım Ltd.Şti.
              <br />
              Tüm hakları saklıdır.
            </p>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
                <span className="text-accent-foreground font-bold text-sm">f</span>
              </div>
              <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
                <span className="text-accent-foreground font-bold text-sm">t</span>
              </div>
              <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
                <span className="text-accent-foreground font-bold text-sm">in</span>
              </div>
              <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
                <span className="text-accent-foreground font-bold text-sm">@</span>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
